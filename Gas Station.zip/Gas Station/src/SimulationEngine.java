import java.util.List;
import java.util.ArrayList;
import java.util.Queue;
import java.util.LinkedList;
import java.util.Random;

public class SimulationEngine {
    private List<GasPump> pumps;
    private Queue<Car> arrivalQueue;
    private Random random;
    private int simulationTime;
    private int totalServed;
    private int totalLeft;
    private double markupPercent;
    private List<FuelStatistics> fuelStatisticsList;
    private double arrivalRate;

    public SimulationEngine(int numPumps, int maxQueueSize, double markupPercent) {
        this.pumps = new ArrayList<>();
        this.arrivalQueue = new LinkedList<>();
        this.random = new Random();
        this.simulationTime = 0;
        this.totalServed = 0;
        this.totalLeft = 0;
        this.markupPercent = markupPercent;
        this.fuelStatisticsList = new ArrayList<>();

        String[] fuelTypes = {"АИ-92", "АИ-95", "АИ-98", "ДТ"};
        for (String type : fuelTypes) {
            fuelStatisticsList.add(new FuelStatistics(type));
        }

        for (int i = 0; i < numPumps; i++) {
            String type = fuelTypes[i % fuelTypes.length];
            pumps.add(new GasPump(i, type, maxQueueSize));
        }

        this.arrivalRate = 0.5;
    }

    public void simulateStep() {
        simulationTime++;
        generateArrivals();
        distributeCars();
        serviceCars();
    }

    private void generateArrivals() {
        double hour = getCurrentHour();
        double timeMultiplier = getTimeMultiplier(hour);

        double effectiveRate = arrivalRate * timeMultiplier * (1.0 - markupPercent * 0.03);

        int arrivals = 0;
        while (random.nextDouble() < effectiveRate) {
            arrivals++;
        }

        String[] fuelTypes = {"АИ-92", "АИ-95", "АИ-98", "ДТ"};
        for (int i = 0; i < arrivals; i++) {
            String fuelType = fuelTypes[random.nextInt(fuelTypes.length)];
            int fuelVolume = 10 + random.nextInt(41);
            Car car = new Car(simulationTime, fuelType, fuelVolume);
            arrivalQueue.offer(car);
        }
    }

    private double getTimeMultiplier(double hour) {
        if ((hour >= 7 && hour <= 10) || (hour >= 17 && hour <= 20)) {
            return 4.0;
        } else if (hour >= 0 && hour <= 5) {
            return 0.5;
        }
        return 2.0;
    }

    private void distributeCars() {
        while (!arrivalQueue.isEmpty()) {
            Car car = arrivalQueue.poll();
            GasPump selectedPump = findBestPump(car.getFuelType());

            if (selectedPump != null && selectedPump.canJoinQueue()) {
                selectedPump.addToQueue(car);
            } else {
                totalLeft++;
            }
        }
    }

    private GasPump findBestPump(String fuelType) {
        List<GasPump> suitablePumps = new ArrayList<>();

        for (GasPump pump : pumps) {
            if (pump.getFuelType().equals(fuelType)) {
                suitablePumps.add(pump);
            }
        }

        if (suitablePumps.isEmpty()) {
            return null;
        }

        GasPump bestPump = suitablePumps.get(0);
        for (GasPump pump : suitablePumps) {
            if (pump.getQueueSize() < bestPump.getQueueSize()) {
                bestPump = pump;
            }
        }

        return bestPump;
    }

    private void serviceCars() {
        for (GasPump pump : pumps) {
            if (pump.isBusy()) {
                pump.decrementServiceTime();
                if (!pump.isBusy()) {
                    Car servedCar = pump.getCurrentCar();
                    if (servedCar != null) {
                        totalServed++;
                        for (FuelStatistics stats : fuelStatisticsList) {
                            if (stats.getFuelType().equals(servedCar.getFuelType())) {
                                stats.addSale(servedCar.getFuelVolume());
                                break;
                            }
                        }
                    }
                    pump.completeService();
                }
            } else if (pump.getQueueSize() > 0) {
                Car nextCar = pump.removeFromQueue();
                int serviceTime = calculateServiceTime(nextCar.getFuelVolume());
                pump.startService(nextCar, serviceTime);
            }
        }
    }

    private int calculateServiceTime(int fuelVolume) {
        if (fuelVolume <= 20) return 1;
        else if (fuelVolume <= 35) return 2;
        else return 3;
    }

    public List<GasPump> getPumps() { return pumps; }
    public int getNumPumps() { return pumps.size(); }
    public int getSimulationTime() { return simulationTime; }
    public int getTotalServed() { return totalServed; }
    public int getTotalLeft() { return totalLeft; }
    public double getMarkupPercent() { return markupPercent; }
    public List<FuelStatistics> getFuelStatisticsList() { return fuelStatisticsList; }

    public int getCurrentDay() {
        return (simulationTime / (24 * 60)) % 7 + 1;
    }

    public int getCurrentHour() {
        return (simulationTime / 60) % 24;
    }

    public double getTotalFuelSold() {
        double total = 0;
        for (GasPump pump : pumps) {
            total += pump.getTotalFuelSold();
        }
        return total;
    }

    public double getProfit() {
        double basePrice = 45.0;
        double profitPerLiter = basePrice * (markupPercent / 100.0);
        return getTotalFuelSold() * profitPerLiter;
    }

    public void setMarkupPercent(double markupPercent) {
        this.markupPercent = markupPercent;
    }
}