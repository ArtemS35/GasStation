import javax.swing.*;
import java.awt.*;

public class ControlPanel extends JPanel {
    private Main mainFrame;
    private JButton startButton, pauseButton, resetButton;
    private JSlider speedSlider;
    private JComboBox<Integer> pumpsCombo, queueCombo;
    private JSpinner markupSpinner;

    public ControlPanel(Main mainFrame) {
        this.mainFrame = mainFrame;
        setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(74, 111, 165), 2),
                "Управление симуляцией",
                0, 0,
                new Font("Arial", Font.BOLD, 14),
                new Color(74, 111, 165)
        ));
        setLayout(new FlowLayout(FlowLayout.CENTER, 15, 10));
        setBackground(new Color(240, 240, 245));

        add(new JLabel("Количество автоматов (K):"));
        pumpsCombo = new JComboBox<>(new Integer[]{3, 4, 5, 6, 7});
        pumpsCombo.setSelectedItem(mainFrame.numPumps);
        pumpsCombo.addActionListener(e -> {
            mainFrame.numPumps = (Integer) pumpsCombo.getSelectedItem();
            mainFrame.resetSimulation();
        });
        add(pumpsCombo);

        add(new JLabel("Макс. длина очереди (N):"));
        queueCombo = new JComboBox<>(new Integer[]{5, 6, 7, 8, 9});
        queueCombo.setSelectedItem(mainFrame.maxQueueSize);
        queueCombo.addActionListener(e -> {
            mainFrame.maxQueueSize = (Integer) queueCombo.getSelectedItem();
            mainFrame.resetSimulation();
        });
        add(queueCombo);

        add(new JLabel("Наценка (%):"));
        SpinnerModel model = new SpinnerNumberModel(10.0, 5.0, 15.0, 0.5);
        markupSpinner = new JSpinner(model);
        markupSpinner.addChangeListener(e -> {
            mainFrame.markupPercent = (Double) markupSpinner.getValue();
            mainFrame.engine.setMarkupPercent(mainFrame.markupPercent);
        });
        add(markupSpinner);

        add(new JLabel("Скорость:"));
        speedSlider = new JSlider(50, 500, 100);
        speedSlider.setInverted(true);
        speedSlider.addChangeListener(e -> {
            mainFrame.simulationSpeed = speedSlider.getValue();
            if (mainFrame.simulationTimer != null) {
                mainFrame.simulationTimer.setDelay(mainFrame.simulationSpeed);
            }
        });
        add(speedSlider);

        startButton = new JButton("Старт");
        startButton.addActionListener(e -> mainFrame.startSimulation());
        add(startButton);

        pauseButton = new JButton("Пауза");
        pauseButton.addActionListener(e -> mainFrame.pauseSimulation());
        add(pauseButton);

        resetButton = new JButton("Сброс");
        resetButton.addActionListener(e -> mainFrame.resetSimulation());
        add(resetButton);
    }
}