public class Car {
    private int arrivalTime;
    private String fuelType;
    private int fuelVolume;
    private int serviceTime;

    public Car(int arrivalTime, String fuelType, int fuelVolume) {
        this.arrivalTime = arrivalTime;
        this.fuelType = fuelType;
        this.fuelVolume = fuelVolume;
        this.serviceTime = calculateServiceTime(fuelVolume);
    }

    private int calculateServiceTime(int volume) {
        if (volume <= 20) return 1;
        else if (volume <= 35) return 2;
        else return 3;
    }

    public int getArrivalTime() { return arrivalTime; }
    public String getFuelType() { return fuelType; }
    public int getFuelVolume() { return fuelVolume; }
    public int getServiceTime() { return serviceTime; }
}