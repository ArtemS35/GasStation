import java.util.List;
import javax.swing.*;
import java.awt.*;

public class Main extends JFrame {
    SimulationEngine engine;
    SimulationPanel simulationPanel;
    StatisticsPanel statsPanel;
    ControlPanel controlPanel;
    TimerPanel timerPanel;
    Timer simulationTimer;
    int numPumps = 5;
    int maxQueueSize = 7;
    double markupPercent = 10.0;
    int simulationSpeed = 100;

    public Main() {
        setTitle("Симуляция работы бензозаправочной станции");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        engine = new SimulationEngine(numPumps, maxQueueSize, markupPercent);

        timerPanel = new TimerPanel(engine);
        simulationPanel = new SimulationPanel(engine);
        statsPanel = new StatisticsPanel(engine);
        controlPanel = new ControlPanel(this);

        JScrollPane scrollPane = new JScrollPane(simulationPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        add(timerPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(statsPanel, BorderLayout.EAST);
        add(controlPanel, BorderLayout.SOUTH);

        setSize(1600, 900);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    void startSimulation() {
        if (simulationTimer != null) {
            simulationTimer.stop();
        }
        simulationTimer = new Timer(simulationSpeed, e -> {
            engine.simulateStep();
            simulationPanel.repaint();
            timerPanel.repaint();
            statsPanel.updateStatistics();
        });
        simulationTimer.start();
    }

    void pauseSimulation() {
        if (simulationTimer != null) {
            simulationTimer.stop();
        }
    }

    void resetSimulation() {
        if (simulationTimer != null) {
            simulationTimer.stop();
        }
        engine = new SimulationEngine(numPumps, maxQueueSize, markupPercent);
        timerPanel = new TimerPanel(engine);
        simulationPanel = new SimulationPanel(engine);
        statsPanel = new StatisticsPanel(engine);

        JScrollPane scrollPane = new JScrollPane(simulationPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        getContentPane().removeAll();
        add(timerPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(statsPanel, BorderLayout.EAST);
        add(controlPanel, BorderLayout.SOUTH);

        revalidate();
        repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new Main();
        });
    }
}