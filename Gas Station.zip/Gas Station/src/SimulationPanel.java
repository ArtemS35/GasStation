import javax.swing.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class SimulationPanel extends JPanel {
    private SimulationEngine engine;

    public SimulationPanel(SimulationEngine engine) {
        this.engine = engine;
        setPreferredSize(new Dimension(1000, 1000));
        setBackground(new Color(240, 240, 245));
    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int pumpWidth = 180;
        int pumpHeight = 280;
        int startX = 40;
        int startY = 30;
        int gapX = 30;
        int gapY = 40;

        for (int i = 0; i < engine.getNumPumps(); i++) {
            int x = startX + (i % 3) * (pumpWidth + gapX);
            int y = startY + (i / 3) * (pumpHeight + gapY);

            GasPump pump = engine.getPumps().get(i);

            g2d.setColor(new Color(220, 220, 225));
            RoundRectangle2D roundedRect = new RoundRectangle2D.Float(x, y, pumpWidth, pumpHeight, 15, 15);
            g2d.fill(roundedRect);

            g2d.setColor(new Color(74, 111, 165));
            g2d.setStroke(new BasicStroke(2));
            g2d.draw(roundedRect);

            g2d.setColor(new Color(51, 51, 51));
            g2d.setFont(new Font("Arial", Font.BOLD, 16));
            g2d.drawString("Автомат " + (i + 1), x + 15, y + 30);

            g2d.setFont(new Font("Arial", Font.PLAIN, 14));
            g2d.drawString(pump.getFuelType(), x + 15, y + 55);

            g2d.setColor(new Color(100, 100, 100));
            g2d.setFont(new Font("Arial", Font.PLAIN, 12));
            g2d.drawString("Очередь: " + pump.getQueueSize() + "/" + pump.getMaxQueueSize(), x + 15, y + 80);

            int queueStartY = y + 100;
            int carWidth = 35;
            int carHeight = 20;
            int carGap = 8;

            for (int j = 0; j < pump.getQueueSize(); j++) {
                int carX = x + 15 + (j % 4) * (carWidth + carGap);
                int carY = queueStartY + (j / 4) * (carHeight + carGap);

                drawCar(g2d, carX, carY, carWidth, carHeight);
            }

            if (pump.isBusy()) {
                int serviceX = x + 15;
                int serviceY = y + pumpHeight - 50;

                g2d.setColor(new Color(200, 200, 205));
                g2d.fillRoundRect(serviceX, serviceY, pumpWidth - 30, 30, 10, 10);

                double progress = 1.0 - (pump.getRemainingServiceTime() / 3.0);
                int progressWidth = (int) ((pumpWidth - 30) * progress);

                g2d.setColor(new Color(100, 140, 100));
                g2d.fillRoundRect(serviceX, serviceY, progressWidth, 30, 10, 10);

                g2d.setColor(new Color(51, 51, 51));
                g2d.setFont(new Font("Arial", Font.PLAIN, 11));
                g2d.drawString("Обслуживание", serviceX + 10, serviceY + 20);
            }
        }
    }

    private void drawCar(Graphics2D g2d, int x, int y, int width, int height) {
        g2d.setColor(new Color(160, 160, 165));
        g2d.fillRoundRect(x, y + height / 2, width, height / 2, 5, 5);
        g2d.fillRoundRect(x + width / 4, y, width / 2, height / 2, 5, 5);

        g2d.setColor(new Color(80, 80, 80));
        g2d.fillOval(x + 5, y + height - 5, 8, 8);
        g2d.fillOval(x + width - 13, y + height - 5, 8, 8);
    }
}