import javax.swing.*;
import java.awt.*;
import java.text.DecimalFormat;
import java.util.List;

public class StatisticsPanel extends JPanel {
    private SimulationEngine engine;
    private JTextArea statsText;
    private DecimalFormat df = new DecimalFormat("#.##");

    public StatisticsPanel(SimulationEngine engine) {
        this.engine = engine;
        setPreferredSize(new Dimension(320, 700));
        setLayout(new BorderLayout());
        setBackground(new Color(240, 240, 245));
        setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(74, 111, 165), 2),
                "Статистика",
                0, 0,
                new Font("Arial", Font.BOLD, 14),
                new Color(74, 111, 165)
        ));

        statsText = new JTextArea();
        statsText.setEditable(false);
        statsText.setFont(new Font("Monospaced", Font.PLAIN, 12));
        statsText.setBackground(new Color(250, 250, 252));
        add(new JScrollPane(statsText), BorderLayout.CENTER);

        updateStatistics();
    }

    public void updateStatistics() {
        StringBuilder sb = new StringBuilder();
        sb.append("Время: ").append(engine.getSimulationTime()).append(" мин\n");
        sb.append("День: ").append(engine.getCurrentDay()).append("\n");
        sb.append("Час: ").append(engine.getCurrentHour()).append("\n\n");

        sb.append("АВТОМАТЫ\n");
        sb.append("─────────────────\n");
        for (int i = 0; i < engine.getNumPumps(); i++) {
            GasPump pump = engine.getPumps().get(i);
            sb.append("Автомат ").append(i + 1).append(" (")
                    .append(pump.getFuelType()).append("):\n");
            sb.append("  Очередь: ").append(pump.getQueueSize()).append("\n");
            sb.append("  Обслужено: ").append(pump.getServedCount()).append("\n");
            sb.append("  Продано: ").append(df.format(pump.getTotalFuelSold())).append(" л\n\n");
        }

        sb.append("ОБЩАЯ СТАТИСТИКА\n");
        sb.append("─────────────────\n");
        sb.append("Всего обслужено: ").append(engine.getTotalServed()).append("\n");
        sb.append("Уехало без заправки: ").append(engine.getTotalLeft()).append("\n");
        sb.append("Всего продано: ").append(df.format(engine.getTotalFuelSold())).append(" л\n");
        sb.append("Прибыль: ").append(df.format(engine.getProfit())).append(" руб.\n\n");

        sb.append("ПО МАРКАМ\n");
        sb.append("─────────────────\n");
        List<FuelStatistics> statsList = engine.getFuelStatisticsList();
        for (FuelStatistics stats : statsList) {
            sb.append(stats.getFuelType()).append(":\n");
            sb.append("  Продано: ").append(df.format(stats.getTotalSold())).append(" л\n");
            sb.append("  Клиентов: ").append(stats.getCustomerCount()).append("\n\n");
        }

        statsText.setText(sb.toString());
    }
}