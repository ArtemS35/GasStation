public class FuelStatistics {
    private String fuelType;
    private double totalSold;
    private int customerCount;
    private double dailySold;
    private double weeklySold;

    public FuelStatistics(String fuelType) {
        this.fuelType = fuelType;
        this.totalSold = 0;
        this.customerCount = 0;
        this.dailySold = 0;
        this.weeklySold = 0;
    }

    public void addSale(int volume) {
        this.totalSold += volume;
        this.customerCount++;
        this.dailySold += volume;
        this.weeklySold += volume;
    }

    public void resetDaily() {
        this.dailySold = 0;
    }

    public void resetWeekly() {
        this.weeklySold = 0;
    }

    public String getFuelType() { return fuelType; }
    public double getTotalSold() { return totalSold; }
    public int getCustomerCount() { return customerCount; }
    public double getDailySold() { return dailySold; }
    public double getWeeklySold() { return weeklySold; }
}