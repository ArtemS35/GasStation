import javax.swing.*;
import java.awt.*;

public class TimerPanel extends JPanel {
    private SimulationEngine engine;

    public TimerPanel(SimulationEngine engine) {
        this.engine = engine;
        setPreferredSize(new Dimension(1200, 70));
        setBackground(new Color(230, 230, 235));
    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        g2d.setColor(new Color(74, 111, 165));
        g2d.setFont(new Font("Arial", Font.BOLD, 18));
        g2d.drawString("Время: " + engine.getSimulationTime() + " мин", 30, 30);

        g2d.setColor(new Color(100, 140, 100));
        g2d.drawString("Обслужено: " + engine.getTotalServed(), 30, 55);

        g2d.setColor(new Color(160, 100, 100));
        g2d.drawString("Уехало: " + engine.getTotalLeft(), 300, 55);

        g2d.setColor(new Color(74, 111, 165));
        g2d.drawString("День " + engine.getCurrentDay() + ", Час " + engine.getCurrentHour(), 300, 30);

        g2d.setColor(new Color(100, 100, 100));
        g2d.drawString("Прибыль: " + String.format("%.2f", engine.getProfit()) + " руб.", 600, 30);

        g2d.drawString("Продано: " + String.format("%.1f", engine.getTotalFuelSold()) + " л", 600, 55);
    }
}