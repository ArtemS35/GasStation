import java.util.LinkedList;
import java.util.Queue;

public class GasPump {
    private int id;
    private String fuelType;
    private Queue<Car> queue;
    private int maxQueueSize;
    private Car currentCar;
    private int remainingServiceTime;
    private int servedCount;
    private double totalFuelSold;

    public GasPump(int id, String fuelType, int maxQueueSize) {
        this.id = id;
        this.fuelType = fuelType;
        this.maxQueueSize = maxQueueSize;
        this.queue = new LinkedList<>();
        this.currentCar = null;
        this.remainingServiceTime = 0;
        this.servedCount = 0;
        this.totalFuelSold = 0;
    }

    public boolean canJoinQueue() {
        return queue.size() < maxQueueSize;
    }

    public void addToQueue(Car car) {
        if (canJoinQueue()) {
            queue.offer(car);
        }
    }

    public Car removeFromQueue() {
        return queue.poll();
    }

    public void startService(Car car, int serviceTime) {
        this.currentCar = car;
        this.remainingServiceTime = serviceTime;
    }

    public void decrementServiceTime() {
        if (remainingServiceTime > 0) {
            remainingServiceTime--;
        }
    }

    public void completeService() {
        if (currentCar != null) {
            totalFuelSold += currentCar.getFuelVolume();
            servedCount++;
            currentCar = null;
        }
    }

    public int getId() { return id; }
    public String getFuelType() { return fuelType; }
    public int getQueueSize() { return queue.size(); }
    public int getMaxQueueSize() { return maxQueueSize; }
    public boolean isBusy() { return currentCar != null && remainingServiceTime > 0; }
    public Car getCurrentCar() { return currentCar; }
    public int getRemainingServiceTime() { return remainingServiceTime; }
    public int getServedCount() { return servedCount; }
    public double getTotalFuelSold() { return totalFuelSold; }
}